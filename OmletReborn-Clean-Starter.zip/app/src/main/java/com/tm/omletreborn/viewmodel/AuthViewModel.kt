package com.tm.omletreborn.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.google.firebase.auth.FirebaseAuth

class AuthViewModel : ViewModel() {
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()

    var currentUser by mutableStateOf(auth.currentUser)
    var errorMessage by mutableStateOf<String?>(null)
    var isLoading by mutableStateOf(false)

    fun login(email: String, pass: String, onSuccess: () -> Unit) {
        if (email.isBlank() || pass.isBlank()) {
            errorMessage = "Vui lòng nhập đầy đủ email và mật khẩu."
            return
        }
        isLoading = true
        errorMessage = null
        auth.signInWithEmailAndPassword(email, pass)
            .addOnCompleteListener { task ->
                isLoading = false
                if (task.isSuccessful) {
                    currentUser = auth.currentUser
                    onSuccess()
                } else {
                    errorMessage = task.exception?.localizedMessage ?: "Đăng nhập thất bại."
                }
            }
    }

    fun register(email: String, pass: String, onSuccess: () -> Unit) {
        if (email.isBlank() || pass.isBlank()) {
            errorMessage = "Vui lòng nhập đầy đủ email và mật khẩu."
            return
        }
        isLoading = true
        errorMessage = null
        auth.createUserWithEmailAndPassword(email, pass)
            .addOnCompleteListener { task ->
                isLoading = false
                if (task.isSuccessful) {
                    currentUser = auth.currentUser
                    onSuccess()
                } else {
                    errorMessage = task.exception?.localizedMessage ?: "Đăng ký thất bại."
                }
            }
    }

    fun logout() {
        auth.signOut()
        currentUser = null
    }
}
