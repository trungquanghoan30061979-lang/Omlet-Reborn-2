package com.tm.omletreborn

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.tm.omletreborn.ui.components.AppBottomBar
import com.tm.omletreborn.ui.components.Screen
import com.tm.omletreborn.ui.screens.*
import com.tm.omletreborn.ui.theme.OmletRebornTheme
import com.tm.omletreborn.viewmodel.AuthViewModel

class MainActivity : ComponentActivity() {
    private val authViewModel: AuthViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            OmletRebornTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val navController = rememberNavController()
                    val navBackStackEntry by navController.currentBackStackEntryAsState()
                    val currentRoute = navBackStackEntry?.destination?.route

                    if (authViewModel.currentUser == null) {
                        AuthScreen(viewModel = authViewModel) {
                            navController.navigate(Screen.Home.route) {
                                popUpTo(0)
                            }
                        }
                    } else {
                        Scaffold(
                            bottomBar = {
                                AppBottomBar(currentRoute = currentRoute ?: Screen.Home.route) { route ->
                                    navController.navigate(route) {
                                        popUpTo(navController.graph.startDestinationId) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            }
                        ) { innerPadding ->
                            NavHost(
                                navController = navController,
                                startDestination = Screen.Home.route,
                                modifier = Modifier.padding(innerPadding)
                            ) {
                                composable(Screen.Home.route) { HomeScreen() }
                                composable(Screen.Rooms.route) { RoomsScreen() }
                                composable(Screen.Profile.route) { ProfileScreen(viewModel = authViewModel) }
                            }
                        }
                    }
                }
            }
        }
    }
}
