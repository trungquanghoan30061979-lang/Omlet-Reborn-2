package com.tm.omletreborn

import android.app.Application

class OmletApp : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
