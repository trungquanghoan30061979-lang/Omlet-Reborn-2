package com.tm.omletreborn.ui.theme

import androidx.compose.ui.graphics.Color

val BluePrimary = Color(0xFF1E88E5)
val BlueDark = Color(0xFF0D47A1)
val BlueBackground = Color(0xFF0A0E1A)
val SurfaceDark = Color(0xFF121829)
val TextWhite = Color(0xFFFFFFFF)
val TextGray = Color(0xFF94A3B8)
val AccentCyan = Color(0xFF00E5FF)
