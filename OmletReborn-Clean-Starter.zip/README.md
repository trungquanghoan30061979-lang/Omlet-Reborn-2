# Omlet Reborn

Ứng dụng Android lấy cảm hứng từ Omlet Arcade phiên bản cũ, xây dựng bằng Jetpack Compose, Kotlin và Firebase Authentication.

## Hướng dẫn cài đặt file google-services.json
1. Tải file `google-services.json` từ Firebase Console của bạn (Package name: `com.tm.omletreborn`).
2. Đặt file vào thư mục: `app/google-services.json`.

## Build bằng GitHub Actions
- Workflow tự động chạy khi push lên nhánh `main` hoặc chạy thủ công tại tab Actions.
- Artifact tên `OmletReborn-debug-apk`.
